<script>
export let value = {
  'image1': '',
  'image2': '',
  'scale': '',
  'path':''
}
let source, target
let img_name

$: if(source && target) {
  value.image1 = source[0].name
  value.image2 = target[0].name
}
$: if(source){
    console.log(source[0].name)
    document.getElementById('img1').src = window.URL.createObjectURL(source[0])
}
</script>

<template lang='pug'>
.inline-block.content-centers.mb-4
  .inline-block.content-centers
    .mb-5.content-centers
      img.border-solid.border-4.border-light-blue-500.object-contain.h-40.w-40(id="img1" src="src/assets/noimage.gif" alt="img1_name")
    label.mx-7.my-3.w-50.px-5.py-2.bg-white.rounded-md.shadow-md.tracking-wide.uppercase.border.border-blue.cursor-pointer.text-blue-600.ease-linear.transition-all.duration-150(class="hover:bg-blue-600 hover:text-white")
      i.fas.fa-cloud-upload-alt.fa-3x
      span.mt-4.text-base.leading-normal Source
      input.hidden(type='file' id='input_train' bind:files='{source}')
  .inline-block.content-centers.mx-5
    .mb-5
      img.border-solid.border-4.border-light-blue-500.object-contain.h-40.w-40(id="img2" src="src/assets/noimage.gif" alt="img2_name")
    label.mx-7.items-center.my-3.px-5.py-2.bg-white.rounded-md.shadow-md.tracking-wide.uppercase.border.border-blue.cursor-pointer.text-blue-600.ease-linear.transition-all.duration-150(class="hover:bg-blue-600 hover:text-white")
      i.fas.fa-cloud-upload-alt.fa-3x
      span.mt-2.text-base.leading-normal Target
      input.hidden(type='file' bind:files='{target}' onchange="document.getElementById('img2').src = window.URL.createObjectURL(this.files[0])")
.flex.flex-col.items-center.content-centers
  span Scale
  input.text-center.my-2.px-4.py-2.rounded-lg.border.border-gray-300.text-xs.w-20(type='number' id='scalenum' class='focus:outline-none focus:ring-2 focus:ring-gray-200' bind:value='{value.scale}')
.flex.flex-col.items-center.content-centers
</template>
<style>
</style>

